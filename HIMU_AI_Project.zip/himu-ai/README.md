# HIMU AI
See [README-BN.md](README-BN.md) for Bengali setup instructions.
Starter project: Next.js + Supabase Auth foundation + Gemini chat API.

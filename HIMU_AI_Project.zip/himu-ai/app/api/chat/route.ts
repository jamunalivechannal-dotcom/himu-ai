import { NextRequest, NextResponse } from "next/server";

type HistoryItem = { role: "user" | "assistant"; content: string };

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const message = typeof body.message === "string" ? body.message.trim() : "";
    const history: HistoryItem[] = Array.isArray(body.history) ? body.history.slice(-12) : [];
    if (!message) return NextResponse.json({ error: "একটি মেসেজ লিখুন।" }, { status: 400 });
    if (message.length > 8000) return NextResponse.json({ error: "মেসেজটি খুব বড়।" }, { status: 400 });

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return NextResponse.json({ error: "GEMINI_API_KEY সেট করা হয়নি। .env.local ফাইলে API key যোগ করুন।" }, { status: 503 });

    const model = process.env.GEMINI_MODEL || "gemini-3.8-flash";
    const contents = [
      ...history.filter((m) => (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
        .map(m => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content.slice(0, 8000) }] })),
      { role: "user", parts: [{ text: message }] }
    ];

    const result = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: "You are HIMU, a friendly, helpful personal AI assistant. Reply in the language used by the user, preferably clear natural Bengali when the user writes Bengali. Be honest about uncertainty." }] },
        contents,
        generationConfig: { temperature: 0.7, maxOutputTokens: 2048 }
      }),
      cache: "no-store"
    });

    const data = await result.json();
    if (!result.ok) {
      const detail = data?.error?.message || "Gemini API request failed.";
      return NextResponse.json({ error: detail }, { status: result.status });
    }
    const reply = data?.candidates?.[0]?.content?.parts?.map((p: {text?:string}) => p.text || "").join("").trim();
    if (!reply) return NextResponse.json({ error: "AI কোনো উত্তর দেয়নি। আবার চেষ্টা করুন।" }, { status: 502 });
    return NextResponse.json({ reply });
  } catch {
    return NextResponse.json({ error: "অনুরোধটি প্রসেস করা যায়নি।" }, { status: 500 });
  }
}

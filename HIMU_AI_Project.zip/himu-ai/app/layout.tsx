import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "HIMU AI — Your Personal AI Assistant",
  description: "HIMU AI: a friendly personal AI assistant."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="bn"><body>{children}</body></html>;
}

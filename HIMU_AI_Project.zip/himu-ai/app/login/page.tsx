 "use client";
import { useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [mode,setMode] = useState<"login"|"signup">("login");
  const [message,setMessage] = useState("");
  const [busy,setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setMessage(""); setBusy(true);
    try {
      const supabase = createClient();
      const result = mode === "login"
        ? await supabase.auth.signInWithPassword({email,password})
        : await supabase.auth.signUp({email,password});
      if (result.error) throw result.error;
      setMessage(mode === "login" ? "লগইন সফল। হোম পেজে ফিরে যান।" : "অ্যাকাউন্ট তৈরি হয়েছে। ইমেইল যাচাই করতে হতে পারে।");
    } catch (err) { setMessage(err instanceof Error ? err.message : "সমস্যা হয়েছে।"); }
    finally { setBusy(false); }
  }

  return <main className="authbox">
    <Link href="/" style={{color:"#e6c77b"}}>← HIMU AI</Link>
    <h1>{mode==="login"?"লগইন":"নতুন অ্যাকাউন্ট"}</h1>
    <p style={{color:"#a69a82",fontSize:13}}>Supabase Authentication</p>
    <form onSubmit={submit}>
      <label>ইমেইল</label><input className="field" type="email" required value={email} onChange={e=>setEmail(e.target.value)} />
      <label>পাসওয়ার্ড</label><input className="field" type="password" minLength={6} required value={password} onChange={e=>setPassword(e.target.value)} />
      <button className="goldbtn" disabled={busy}>{busy?"অপেক্ষা করুন…":mode==="login"?"লগইন":"অ্যাকাউন্ট তৈরি"}</button>
    </form>
    {message && <p className="error" style={{marginTop:14}}>{message}</p>}
    <p style={{marginTop:20,fontSize:13,color:"#b7aa8d"}}>{mode==="login"?"নতুন ব্যবহারকারী?":"আগে অ্যাকাউন্ট আছে?"} <button onClick={()=>{setMode(mode==="login"?"signup":"login");setMessage("");}} style={{background:"none",border:0,color:"#e6c77b",cursor:"pointer"}}>{mode==="login"?"অ্যাকাউন্ট তৈরি করুন":"লগইন করুন"}</button></p>
  </main>;
}

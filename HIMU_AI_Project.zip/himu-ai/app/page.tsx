import Chat from "@/components/Chat";
import { createClient } from "@/lib/supabase/server";

export default async function Home() {
  let user: { email?: string } | null = null;
  try {
    const supabase = await createClient();
    const { data } = await supabase.auth.getUser();
    user = data.user;
  } catch { /* App can show setup guidance before env is configured. */ }
  return <Chat email={user?.email ?? null} />;
}

 "use client";

import { useState } from "react";
import Link from "next/link";

type Message = { role: "user" | "assistant"; content: string };

const suggestions = [
  "আমাকে আজকের কাজের একটি পরিকল্পনা করে দাও",
  "বাংলায় একটি সুন্দর ইমেইল লিখে দাও",
  "একটি নতুন ব্যবসার আইডিয়া দাও",
  "জটিল বিষয় সহজ ভাষায় বুঝিয়ে দাও"
];

export default function Chat({ email }: { email: string | null }) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function send(text = input) {
    const prompt = text.trim();
    if (!prompt || loading) return;
    setError("");
    setMessages(old => [...old, { role: "user", content: prompt }]);
    setInput("");
    setLoading(true);
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: prompt, history: messages.slice(-12) })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "উত্তর আনা যায়নি।");
      setMessages(old => [...old, { role: "assistant", content: data.reply }]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "একটি সমস্যা হয়েছে।");
    } finally { setLoading(false); }
  }

  return <div className="shell">
    <aside className="sidebar">
      <div className="brand">HIMU<small>PERSONAL AI</small></div>
      <button className="newchat" onClick={() => { setMessages([]); setError(""); }}>＋ নতুন চ্যাট</button>
      <div style={{color:"#9b907a",fontSize:13}}>তোমার ব্যক্তিগত AI সহকারী</div>
      <div className="side-note">HIMU AI<br/>একটি প্রাথমিক সংস্করণ<br/><br/>ছবি, ভিডিও, ভয়েস ও উন্নত টুল পরবর্তী ধাপে যুক্ত হবে।</div>
    </aside>
    <main className="main">
      <header className="topbar">
        <strong>HIMU AI <span style={{color:"#9a8a65",fontWeight:400}}> / চ্যাট</span></strong>
        <div style={{display:"flex",gap:14,alignItems:"center"}}>
          <span className="status">● AI সহকারী</span>
          {email ? <span style={{fontSize:12,color:"#b9ad92"}}>{email}</span> : <Link href="/login" style={{color:"#e6c77b",fontSize:13}}>লগইন</Link>}
        </div>
      </header>
      <section className="content">
        {messages.length === 0 ? <div className="welcome">
          <h1>হ্যালো! আমি HIMU</h1>
          <p>আমি তোমার ব্যক্তিগত AI সহকারী। কীভাবে সাহায্য করতে পারি?</p>
          <div className="prompts">{suggestions.map(s => <button className="prompt" key={s} onClick={() => send(s)}>{s} ↗</button>)}</div>
        </div> : <div className="messages">{messages.map((m,i) => <div className={`msg ${m.role}`} key={i}>{m.content}</div>)}{loading && <div className="msg assistant">HIMU ভাবছে…</div>}</div>}
        {error && <p className="error">{error}</p>}
      </section>
      <div className="composer-wrap">
        <div className="composer">
          <textarea value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}}} placeholder="HIMU-কে কিছু জিজ্ঞেস করো…" />
          <button className="send" disabled={!input.trim() || loading} onClick={()=>send()}>পাঠাও</button>
        </div>
        <div className="hint">HIMU ভুলও করতে পারে। গুরুত্বপূর্ণ তথ্য যাচাই করে নেবে।</div>
      </div>
    </main>
  </div>;
}

# HIMU AI — প্রাথমিক প্রজেক্ট

এটি HIMU AI-এর প্রথম চালু করার মতো ওয়েব-অ্যাপ ভিত্তি। এতে আছে:
- Next.js ওয়েব অ্যাপ ও বাংলা চ্যাট UI
- Gemini API দিয়ে AI chat endpoint
- Supabase email/password authentication
- Supabase profile, conversation ও messages টেবিলের SQL
- `.env.example` কনফিগারেশন নমুনা

**গুরুত্বপূর্ণ:** এই সংস্করণটি সম্পূর্ণ HIMU প্ল্যাটফর্মের প্রথম ভিত্তি, চূড়ান্ত সব ফিচার নয়। ছবি/ভিডিও তৈরি ও এডিট, ভয়েস, স্থায়ী মেমোরি, পেমেন্ট, অ্যাডমিন প্যানেল এবং Cloudflare deployment পরবর্তী ধাপে যোগ করতে হবে। বর্তমান চ্যাটের কথোপকথন ব্রাউজারের state-এ থাকে; এখনো Supabase-এ সেভ হয় না।

## ১. যা লাগবে
- GitHub account
- Supabase project
- Google AI Studio থেকে Gemini API key
- Node.js 20.9 বা নতুন সংস্করণ (লোকাল কম্পিউটার/সমর্থিত cloud development environment)

## ২. সেটআপ
1. ZIP extract করে GitHub-এ `himu-ai` নামে repository তৈরি করে ফাইলগুলো upload করুন।
2. Supabase project খুলে SQL Editor-এ যান।
3. `supabase/schema.sql`-এর সম্পূর্ণ কোড paste করে Run চাপুন।
4. Supabase Project Settings → API থেকে Project URL এবং anon/public key নিন।
5. Google AI Studio থেকে Gemini API key তৈরি করুন।
6. `.env.example` কপি করে `.env.local` নাম দিন এবং মানগুলো বসান:

```env
NEXT_PUBLIC_SUPABASE_URL=আপনার_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=আপনার_supabase_anon_key
GEMINI_API_KEY=আপনার_gemini_api_key
GEMINI_MODEL=gemini-3.8-flash
```

API key কখনো GitHub-এ upload করবেন না। `.env.local` ফাইল `.gitignore`-এ বাদ রাখা আছে।

## ৩. চালানো
টার্মিনালে:
```bash
npm install
npm run dev
```
তারপর `http://localhost:3000` খুলুন।

## ৪. Cloudflare সম্পর্কে
এই প্রজেক্টটি Next.js Node runtime ভিত্তিক। Cloudflare-এ deploy করতে Cloudflare-এর বর্তমান Next.js/OpenNext নির্দেশনা অনুসরণ করে adapter ও deployment config যোগ করতে হবে। এই ZIP-এ Cloudflare deployment এখনো configure করা হয়নি। প্রথমে স্থানীয় বা GitHub-connected preview-তে পরীক্ষা করুন।

## ৫. নিরাপত্তা
- Gemini key শুধু server-side route-এ ব্যবহৃত হয়।
- Supabase service-role key ব্যবহার করা হয়নি।
- Database tables-এ Row Level Security (RLS) চালু করা হয়েছে।
- Production-এ যাওয়ার আগে rate limiting, abuse protection, logging, privacy policy এবং account recovery যোগ করুন।

## ৬. পরবর্তী কাজের তালিকা
- [ ] Chat history Supabase-এ save/load
- [ ] User profile ও account settings
- [ ] User-consented long-term memory
- [ ] Voice input/output
- [ ] Image generation/editing provider integration
- [ ] Video generation/editing provider integration
- [ ] File upload and document understanding
- [ ] Rate limiting and moderation
- [ ] Cloudflare deployment
- [ ] Mobile-first installable PWA

## সহায়তা
প্রথমে `.env.local`-এর তিনটি মান ঠিকভাবে বসানো আছে কি না যাচাই করুন। Gemini model availability provider account অনুযায়ী বদলাতে পারে; model unavailable দেখালে Google AI Studio-তে আপনার জন্য চালু থাকা model name ব্যবহার করুন।
